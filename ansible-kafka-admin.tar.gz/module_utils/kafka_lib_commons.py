import os
import logging
import traceback
from pkg_resources import parse_version

from ansible.module_utils.kafka_lib_errors import IncompatibleVersion
from ansible.module_utils.kafka_manager import KafkaManager
from ansible.module_utils.ssl_utils import (
    generate_ssl_object, generate_ssl_context
)

# Set up logging for SSL cleanup debugging
ssl_cleanup_logger = logging.getLogger('kafka_ssl_cleanup')
ssl_cleanup_logger.setLevel(logging.DEBUG)
if not ssl_cleanup_logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    ssl_cleanup_logger.addHandler(handler)

DOCUMENTATION_COMMON = '''
  bootstrap_servers:
    description:
      - 'kafka broker connection.'
      - 'format: host1:port,host2:port'
    required: True
  api_version:
    description:
      - 'kafka API version'
      - 'format: major.minor.patch. Examples: 0.11.0 or 1.0.1'
      - 'if not set, will launch an automatic version discovery but can '
      - 'trigger stackstraces on Kafka server.'
      - 'it is better to set it so that all features are correctly'
      - 'discovered'
    default: auto
  sasl_mechanism:
    description:
      - 'which sasl mechanism to use to connect to Kafka.'
      - 'when using sasl, whether use PLAIN or GSSAPI ' \
        'or SCRAM-SHA-256 or SCRAM-SHA-512 '
    default: PLAIN
    choices: [PLAIN, 'SCRAM-SHA-256', 'SCRAM-SHA-512', GSSAPI]
  security_protocol:
    description:
      - 'how to connect to Kafka.'
     default: PLAINTEXT
     choices: [PLAINTEXT, SASL_PLAINTEXT, SSL, SASL_SSL]
  sasl_plain_username:
    description:
      - 'when using SASL, username to use.'
  sasl_plain_password:
    description:
      - 'when using SASL, password for '
      - 'sasl_plain_username.'
  ssl_check_hostname:
    description:
      - 'when using SSL for Kafka, check if certificate for hostname is '
      - 'correct.'
    default: True
  ssl_cafile:
    description:
      - 'when using SSL for Kafka, content of ca cert file or path to ca '
      - 'cert file.'
  sasl_kerberos_service_name:
    description:
      - 'when using kerberos (SASL GSSAPI), service name.'
  ssl_certfile:
    description:
      - 'when using SSL for Kafka, content of cert file or path to server '
      - 'cert file.'
  ssl_keyfile:
    description:
      - 'when using SSL for kafka, content of keyfile or path to server '
      - 'cert key file.'
  ssl_password:
    description:
      - 'when using SSL for Kafka, password for ssl_keyfile.'
  ssl_crlfile:
    description:
      - 'when using SSL for Kafka, content of crl file or path to cert '
      - 'crl file.'
  request_timeout_ms:
    description:
      - 'timeout for kafka client requests'
      - 'can be used in case some actions are taking lots of time'
    default: 60000
  connections_max_idle_ms:
    description:
      - 'close idle connections after'
    default: 540000
  connect_max_retry:
    description:
      - 'the number of tries before giving up when establishing a Kafka'
      - 'connection for the first time. Current retries are done every 100ms'
      - 'so this value can also be seen as a total time to wait before giving'
      - 'up'.
    default: 50
'''

module_topic_commons = dict(
    partitions=dict(type='int', required=False, default=0),

    replica_factor=dict(type='int', required=False, default=0),

    force_reassign=dict(type='bool', required=False, default=False),

    preserve_leader=dict(type='bool', required=False, default=False),

    preserve_current_replicas=dict(type='bool', required=False, default=False),

    json_assignment=dict(type='json', required=False, default=None),

    options=dict(required=False, type='dict', default={}),
)

acl_operations_choices = [
    'all',
    'alter',
    'alter_configs',
    'cluster_action',
    'create',
    'delete',
    'describe',
    'describe_configs',
    'idempotent_write',
    'read',
    'write'
]

module_acl_commons_validations = dict(
    mutually_exclusive=[
        ('acl_operation', 'acl_operations')
    ],
    required_if=[
        ('state', 'present', ('acl_operation', 'acl_operations'), True)
    ]
)

module_acl_commons = dict(

    name=dict(type='str', required=True),
    state=dict(
        choices=['present', 'absent'],
        default='present'
    ),
    acl_resource_type=dict(
        choices=[
            'topic',
            'broker',
            'cluster',
            'delegation_token',
            'group',
            'transactional_id'
        ],
        default='topic'
    ),

    acl_principal=dict(type='str', required=False),
    acl_operations=dict(
        type='list',
        elements='str',
        choices=acl_operations_choices
    ),
    acl_operation=dict(
        choices=acl_operations_choices,
        required=False
    ),

    acl_pattern_type=dict(
        choice=[
            'any',
            'match',
            'literal',
            'prefixed'
        ],
        required=False,
        default='literal'
    ),

    acl_permission=dict(choices=['allow', 'deny'], default='allow'),
    acl_host=dict(type='str', required=False, default="*"),
)

module_zookeeper_commons = dict(
    zookeeper=dict(type='str', required=False),

    zookeeper_auth_scheme=dict(
        choices=['digest', 'sasl'],
        default='digest'
    ),

    zookeeper_auth_value=dict(
        type='str',
        no_log=True,
        required=False,
        default=''
    ),

    zookeeper_ssl_check_hostname=dict(
        default=True,
        type='bool',
        required=False
    ),

    zookeeper_ssl_cafile=dict(
        required=False,
        default=None,
        type='path'
    ),

    zookeeper_ssl_certfile=dict(
        required=False,
        default=None,
        type='path'
    ),

    zookeeper_ssl_keyfile=dict(
        required=False,
        default=None,
        no_log=True,
        type='path'
    ),

    zookeeper_ssl_password=dict(
        type='str',
        no_log=True,
        required=False
    ),

    zookeeper_sleep_time=dict(type='int', required=False, default=5),

    zookeeper_max_retries=dict(type='int', required=False, default=5),

    zookeeper_use_ssl=dict(type='bool', required=False, default=False),
)

module_commons = dict(
    bootstrap_servers=dict(type='str', required=True),

    security_protocol=dict(
        choices=['PLAINTEXT', 'SSL', 'SASL_SSL', 'SASL_PLAINTEXT'],
        default='PLAINTEXT'
    ),

    api_version=dict(type='str', default=None),

    ssl_check_hostname=dict(
        default=True,
        type='bool',
        required=False
    ),

    ssl_cafile=dict(required=False, default=None, type='path'),

    ssl_certfile=dict(required=False, default=None, type='path'),

    ssl_keyfile=dict(
        required=False,
        default=None,
        no_log=True,
        type='path'
    ),

    ssl_password=dict(type='str', no_log=True, required=False),

    ssl_crlfile=dict(required=False, default=None, type='path'),

    ssl_supported_protocols=dict(
        required=False, default=None, type='list',
        choices=['TLSv1', 'TLSv1.1', 'TLSv1.2']
    ),

    ssl_ciphers=dict(required=False, default=None, type='str'),

    sasl_mechanism=dict(
        choices=['PLAIN', 'GSSAPI', 'SCRAM-SHA-256', 'SCRAM-SHA-512'],
        default='PLAIN'
    ),

    sasl_plain_username=dict(type='str', required=False),

    sasl_plain_password=dict(type='str', no_log=True, required=False),

    sasl_kerberos_service_name=dict(type='str', required=False),

    request_timeout_ms=dict(type='int', default=60000),

    connections_max_idle_ms=dict(type='int', default=540000),

    kafka_sleep_time=dict(type='int', required=False, default=5),

    kafka_max_retries=dict(type='int', required=False, default=5),

    connect_max_retry=dict(type='int', required=False, default=50),
)


def get_manager_from_params(params):

    bootstrap_servers = params['bootstrap_servers']
    security_protocol = params['security_protocol']
    ssl_check_hostname = params['ssl_check_hostname']
    ssl_cafile = params['ssl_cafile']
    ssl_certfile = params['ssl_certfile']
    ssl_keyfile = params['ssl_keyfile']
    ssl_password = params['ssl_password']
    ssl_crlfile = params['ssl_crlfile']
    ssl_supported_protocols = params['ssl_supported_protocols']
    ssl_ciphers = params['ssl_ciphers']
    sasl_mechanism = params['sasl_mechanism']
    sasl_plain_username = params['sasl_plain_username']
    sasl_plain_password = params['sasl_plain_password']
    sasl_kerberos_service_name = params['sasl_kerberos_service_name']
    request_timeout_ms = params['request_timeout_ms']
    connections_max_idle_ms = params['connections_max_idle_ms']
    connect_max_retry = params['connect_max_retry']

    api_version = tuple(
        int(p) for p in params['api_version'].strip(".").split(".")
    ) if params.get('api_version') else None

    kafka_ssl_files = generate_ssl_object(
        ssl_cafile, ssl_certfile, ssl_keyfile, ssl_crlfile
    )

    # Generate ssl context to support limit ssl protocols & ciphers
    ssl_context = None
    if security_protocol in ('SSL', 'SASL_SSL'):
        ssl_context = generate_ssl_context(
            ssl_check_hostname=ssl_check_hostname,
            ssl_cafile=kafka_ssl_files['cafile']['path'],
            ssl_certfile=kafka_ssl_files['certfile']['path'],
            ssl_keyfile=kafka_ssl_files['keyfile']['path'],
            ssl_password=ssl_password,
            ssl_crlfile=kafka_ssl_files['crlfile']['path'],
            ssl_supported_protocols=ssl_supported_protocols,
            ssl_ciphers=ssl_ciphers
        )

    manager = KafkaManager(
        bootstrap_servers=bootstrap_servers,
        security_protocol=security_protocol, api_version=api_version,
        ssl_context=ssl_context,
        sasl_mechanism=sasl_mechanism,
        sasl_plain_username=sasl_plain_username,
        sasl_plain_password=sasl_plain_password,
        sasl_kerberos_service_name=sasl_kerberos_service_name,
        request_timeout_ms=request_timeout_ms,
        connections_max_idle_ms=connections_max_idle_ms,
        connect_max_retry=connect_max_retry
    )

    if parse_version(manager.get_api_version()) < parse_version('0.11.0'):
        raise IncompatibleVersion(
            'Current version of library is not compatible with '
            'Kafka < 0.11.0.'
        )

    if 'kafka_sleep_time' in params:
        manager.kafka_sleep_time = params['kafka_sleep_time']
    if 'kafka_max_retries' in params:
        manager.kafka_max_retries = params['kafka_max_retries']

    if 'zookeeper' in params:
        manager.zk_configuration = get_zookeeper_configuration(params)
    if 'zookeeper_sleep_time' in params:
        manager.zookeeper_sleep_time = params['zookeeper_sleep_time']
    if 'zookeeper_max_retries' in params:
        manager.zookeeper_max_retries = params['zookeeper_max_retries']

    # Store SSL files information for cleanup
    manager.kafka_ssl_files = kafka_ssl_files
    if 'zookeeper' in params and manager.zk_configuration:
        manager.zookeeper_ssl_files = get_zookeeper_ssl_files(params)

    return manager


def maybe_clean_kafka_ssl_files(params, kafka_ssl_files=None):
    """
    Clean up temporary Kafka SSL files.
    
    Args:
        params: Module parameters
        kafka_ssl_files: Optional pre-generated SSL files object to avoid recreation
    """
    ssl_cleanup_logger.debug("Starting SSL temp file cleanup process")
    
    try:
        if kafka_ssl_files is None:
            # Fallback to old behavior if SSL files not provided
            ssl_cafile = params.get('ssl_cafile')
            ssl_certfile = params.get('ssl_certfile')
            ssl_keyfile = params.get('ssl_keyfile')
            ssl_crlfile = params.get('ssl_crlfile')
            
            ssl_cleanup_logger.debug(f"SSL file parameters - cafile: {ssl_cafile}, "
                                   f"certfile: {ssl_certfile}, keyfile: {ssl_keyfile}, "
                                   f"crlfile: {ssl_crlfile}")
            
            if not any([ssl_cafile, ssl_certfile, ssl_keyfile, ssl_crlfile]):
                ssl_cleanup_logger.debug("No SSL files provided, skipping cleanup")
                return
                
            ssl_cleanup_logger.debug("Generating SSL object to identify temp files")
            kafka_ssl_files = generate_ssl_object(
                ssl_cafile, ssl_certfile, ssl_keyfile, ssl_crlfile
            )
        
        ssl_cleanup_logger.debug(f"Generated SSL files object: {kafka_ssl_files}")
        
        cleanup_count = 0
        for key, value in kafka_ssl_files.items():
            ssl_cleanup_logger.debug(f"Processing SSL file type: {key}")
            ssl_cleanup_logger.debug(f"File details - path: {value['path']}, "
                                   f"is_temp: {value['is_temp']}")
            
            if (value['path'] is not None and value['is_temp']):
                ssl_cleanup_logger.debug(f"File {value['path']} is identified as temporary")
                
                # Check if directory exists
                dir_exists = os.path.exists(os.path.dirname(value['path']))
                ssl_cleanup_logger.debug(f"Directory exists for {value['path']}: {dir_exists}")
                
                if dir_exists:
                    # Check if file exists before trying to delete
                    file_exists = os.path.exists(value['path'])
                    ssl_cleanup_logger.debug(f"File exists before deletion: {file_exists}")
                    
                    if file_exists:
                        try:
                            ssl_cleanup_logger.info(f"Attempting to delete temp SSL file: {value['path']}")
                            os.remove(value['path'])
                            cleanup_count += 1
                            ssl_cleanup_logger.info(f"Successfully deleted temp SSL file: {value['path']}")
                        except OSError as e:
                            ssl_cleanup_logger.error(f"Failed to delete temp SSL file {value['path']}: {e}")
                            ssl_cleanup_logger.debug(f"OSError details: {traceback.format_exc()}")
                        except Exception as e:
                            ssl_cleanup_logger.error(f"Unexpected error deleting temp SSL file {value['path']}: {e}")
                            ssl_cleanup_logger.debug(f"Exception details: {traceback.format_exc()}")
                    else:
                        ssl_cleanup_logger.warning(f"Temp SSL file {value['path']} does not exist, skipping deletion")
                else:
                    ssl_cleanup_logger.warning(f"Directory for temp SSL file {value['path']} does not exist, skipping deletion")
            else:
                ssl_cleanup_logger.debug(f"Skipping {key} file - not temporary or no path: "
                                       f"path={value['path']}, is_temp={value['is_temp']}")
        
        ssl_cleanup_logger.info(f"SSL temp file cleanup completed. Files cleaned: {cleanup_count}")
        
    except KeyError as e:
        ssl_cleanup_logger.error(f"Missing required parameter in SSL cleanup: {e}")
        ssl_cleanup_logger.debug(f"KeyError traceback: {traceback.format_exc()}")
    except Exception as e:
        ssl_cleanup_logger.error(f"Unexpected error in SSL temp file cleanup: {e}")
        ssl_cleanup_logger.debug(f"Exception traceback: {traceback.format_exc()}")


def get_zookeeper_ssl_files(params):
    """
    Generate SSL files object for zookeeper without creating configuration.
    This is used for cleanup purposes.
    """
    if ('zookeeper_ssl_cafile' in params and
            'zookeeper_ssl_certfile' in params and
            'zookeeper_ssl_keyfile' in params):
        zookeeper_ssl_cafile = params['zookeeper_ssl_cafile']
        zookeeper_ssl_certfile = params['zookeeper_ssl_certfile']
        zookeeper_ssl_keyfile = params['zookeeper_ssl_keyfile']

        return generate_ssl_object(
            zookeeper_ssl_cafile, zookeeper_ssl_certfile,
            zookeeper_ssl_keyfile
        )
    return None


def get_zookeeper_configuration(params):
    zookeeper = params['zookeeper']
    if zookeeper is not None:
        zookeeper_auth_scheme = params['zookeeper_auth_scheme']
        zookeeper_auth_value = params['zookeeper_auth_value']
        zookeeper_ssl_check_hostname = params['zookeeper_ssl_check_hostname']
        zookeeper_ssl_cafile = params['zookeeper_ssl_cafile']
        zookeeper_ssl_certfile = params['zookeeper_ssl_certfile']
        zookeeper_ssl_keyfile = params['zookeeper_ssl_keyfile']
        zookeeper_ssl_password = params['zookeeper_ssl_password']

        zookeeper_ssl_files = generate_ssl_object(
          zookeeper_ssl_cafile, zookeeper_ssl_certfile,
          zookeeper_ssl_keyfile
        )
        zookeeper_use_ssl = params.get('zookeeper_use_ssl', bool(
            (
                zookeeper_ssl_files['keyfile']['path'] is not None and
                zookeeper_ssl_files['certfile']['path'] is not None
            ) or zookeeper_ssl_files['cafile']['path'] is not None
        ))

        zookeeper_auth = []
        if zookeeper_auth_value != '':
            auth = (zookeeper_auth_scheme, zookeeper_auth_value)
            zookeeper_auth.append(auth)

        return dict(
            hosts=zookeeper,
            auth_data=zookeeper_auth,
            keyfile=zookeeper_ssl_files['keyfile']['path'],
            use_ssl=zookeeper_use_ssl,
            keyfile_password=zookeeper_ssl_password,
            certfile=zookeeper_ssl_files['certfile']['path'],
            ca=zookeeper_ssl_files['cafile']['path'],
            verify_certs=zookeeper_ssl_check_hostname
        )
    return None


def maybe_clean_zk_ssl_files(params, zookeeper_ssl_files=None):
    """
    Clean up temporary ZooKeeper SSL files created during operations.
    This function includes comprehensive debug logging for troubleshooting.
    """
    ssl_cleanup_logger.debug("Starting ZooKeeper SSL temp file cleanup process")
    
    try:
        if zookeeper_ssl_files is None:
            # Fallback to old behavior if SSL files not provided
            if ('zookeeper_ssl_cafile' in params and
                    'zookeeper_ssl_certfile' in params and
                    'zookeeper_ssl_keyfile' in params):
                zookeeper_ssl_cafile = params['zookeeper_ssl_cafile']
                zookeeper_ssl_certfile = params['zookeeper_ssl_certfile']
                zookeeper_ssl_keyfile = params['zookeeper_ssl_keyfile']
                
                ssl_cleanup_logger.debug(f"ZooKeeper SSL file parameters - cafile: {zookeeper_ssl_cafile}, "
                                       f"certfile: {zookeeper_ssl_certfile}, keyfile: {zookeeper_ssl_keyfile}")
                
                if not any([zookeeper_ssl_cafile, zookeeper_ssl_certfile, zookeeper_ssl_keyfile]):
                    ssl_cleanup_logger.debug("No ZooKeeper SSL files provided, skipping cleanup")
                    return
                    
                ssl_cleanup_logger.debug("Generating ZooKeeper SSL object to identify temp files")
                zookeeper_ssl_files = generate_ssl_object(
                    zookeeper_ssl_cafile, zookeeper_ssl_certfile,
                    zookeeper_ssl_keyfile
                )
            else:
                return
            
        ssl_cleanup_logger.debug(f"Generated ZooKeeper SSL files object: {zookeeper_ssl_files}")
        
        cleanup_count = 0
        for key, value in zookeeper_ssl_files.items():
            ssl_cleanup_logger.debug(f"Processing ZooKeeper SSL file type: {key}")
            ssl_cleanup_logger.debug(f"File details - path: {value['path']}, "
                                   f"is_temp: {value['is_temp']}")
            
            if (value['path'] is not None and value['is_temp']):
                ssl_cleanup_logger.debug(f"ZooKeeper file {value['path']} is identified as temporary")
                
                # Check if directory exists
                dir_exists = os.path.exists(os.path.dirname(value['path']))
                ssl_cleanup_logger.debug(f"Directory exists for {value['path']}: {dir_exists}")
                
                if dir_exists:
                    # Check if file exists before trying to delete
                    file_exists = os.path.exists(value['path'])
                    ssl_cleanup_logger.debug(f"ZooKeeper file exists before deletion: {file_exists}")
                    
                    if file_exists:
                        try:
                            ssl_cleanup_logger.info(f"Attempting to delete temp ZooKeeper SSL file: {value['path']}")
                            os.remove(value['path'])
                            cleanup_count += 1
                            ssl_cleanup_logger.info(f"Successfully deleted temp ZooKeeper SSL file: {value['path']}")
                        except OSError as e:
                            ssl_cleanup_logger.error(f"Failed to delete temp ZooKeeper SSL file {value['path']}: {e}")
                            ssl_cleanup_logger.debug(f"OSError details: {traceback.format_exc()}")
                        except Exception as e:
                            ssl_cleanup_logger.error(f"Unexpected error deleting temp ZooKeeper SSL file {value['path']}: {e}")
                            ssl_cleanup_logger.debug(f"Exception details: {traceback.format_exc()}")
                    else:
                        ssl_cleanup_logger.warning(f"Temp ZooKeeper SSL file {value['path']} does not exist, skipping deletion")
                else:
                    ssl_cleanup_logger.warning(f"Directory for temp ZooKeeper SSL file {value['path']} does not exist, skipping deletion")
            else:
                ssl_cleanup_logger.debug(f"Skipping ZooKeeper {key} file - not temporary or no path: "
                                       f"path={value['path']}, is_temp={value['is_temp']}")
        
        ssl_cleanup_logger.info(f"ZooKeeper SSL temp file cleanup completed. Files cleaned: {cleanup_count}")
        
    except KeyError as e:
        ssl_cleanup_logger.error(f"Missing required parameter in ZooKeeper SSL cleanup: {e}")
        ssl_cleanup_logger.debug(f"KeyError traceback: {traceback.format_exc()}")
    except Exception as e:
        ssl_cleanup_logger.error(f"Unexpected error in ZooKeeper SSL temp file cleanup: {e}")
        ssl_cleanup_logger.debug(f"Exception traceback: {traceback.format_exc()}")
